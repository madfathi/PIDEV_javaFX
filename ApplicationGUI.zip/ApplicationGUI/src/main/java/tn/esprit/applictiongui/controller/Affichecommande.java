package tn.esprit.applictiongui.controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.graphics.image.PDImageXObject;
import javafx.scene.input.KeyEvent;
import tn.esprit.applictiongui.model.commande;
import tn.esprit.applictiongui.model.panier;
import tn.esprit.applictiongui.service.commandeservice;
import javafx.scene.input.MouseEvent;

import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.ResourceBundle;

public class Affichecommande {

    @FXML
    private TextField rc;

    @FXML
    private TextField ma;

    @FXML
    private TextField mm;

    @FXML
    private TextField mn;

    @FXML
    private TextField mp;

    @FXML
    private TextField mt;

    ObservableList<commande> list = FXCollections.observableArrayList();
    private final commandeservice cs =new commandeservice();
    private commandeservice css =new commandeservice();

    @FXML
    private TableView<commande> tab;

    @FXML
    private TableColumn<commande, String> taba;

    @FXML
    private TableColumn<commande, String> tabe;

    @FXML
    private TableColumn<commande, String> tabn;

    @FXML
    private TableColumn<commande, String> tabp;
    @FXML
    private TableColumn<commande, String> tabr;
    @FXML
    private TableColumn<commande, Integer> tabt;
    @FXML
    private TableColumn<commande, Integer> tabi;
public int idc,tel;
public String nom,pre,mail,addr,pani;
    public String getPani() {
        return pani;
    }


    public int getIdc() {
        return idc;
    }

    public int getTel() {
        return tel;
    }

    public String getAddr() {
        return addr;
    }

    public String getMail() {
        return mail;
    }

    public String getNom() {
        return nom;
    }

    public String getPre() {
        return pre;
    }

    public void setAddr(String addr) {
        this.addr = addr;
    }

    public void setIdc(int idc) {
        this.idc = idc;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public void setPre(String pre) {
        this.pre = pre;
    }

    public void setTel(int tel) {
        this.tel = tel;
    }

    public void setPani(String pani) {
        this.pani = pani;
    }


    public void SetValue(MouseEvent mouseEvent) throws SQLException, ClassNotFoundException {
        commande selected = tab.getSelectionModel().getSelectedItem();

        if (selected != null) {

            mt.setText(String.valueOf(selected.getTel()));
            mn.setText(selected.getNom());
            mm.setText(selected.getMail());
            ma.setText(selected.getAddr());
            mp.setText(selected.getPre());
            idc = selected.getIdc();
            pani = selected.getPani();


        }
    }
    @FXML
    void suppcommande(ActionEvent event) {
        commande selected=tab.getSelectionModel().getSelectedItem();
        if(selected!=null)
        {
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("Voulez-Vous Supprimer cet Categorie?");
            alert.setContentText("Supprimer?");
            ButtonType okButton = new ButtonType("Yes", ButtonBar.ButtonData.YES);
            ButtonType noButton = new ButtonType("No", ButtonBar.ButtonData.NO);
            ButtonType cancelButton = new ButtonType("Cancel", ButtonBar.ButtonData.CANCEL_CLOSE);
            alert.getButtonTypes().setAll(okButton, noButton, cancelButton);
            alert.showAndWait().ifPresent(type -> {
                if (type == okButton) {
                    try {
                        css.supprimer(selected.getIdc());
                        initialize();
                    } catch (SQLException e) {
                        throw new RuntimeException(e);
                    }
                } else if (type == noButton) {

                        initialize();



                } else {

                        initialize();


                }
            });
        }

    }


    @FXML
    void updatecommande(ActionEvent event) throws SQLException {


        String nomC = mn.getText();
        String pree = mp.getText();
        int te = Integer.parseInt(mt.getText());
        String maa = mm.getText();
        String ad = ma.getText();
        commande c = new commande(idc,te,nomC,pree,maa,ad,pani);
        css.modifier(c);

        Alert al = new Alert(Alert.AlertType.WARNING);

        al.setTitle("Succes");
        al.setContentText("Produit Modifiée");
        al.showAndWait();
        initialize();
    }

    @FXML
    void initialize( ) {
        /*rc.getItems().removeAll(rc.getItems());
        rc.getItems().addAll("Trier", "Trier par Nom ↑", "Trier par Nom ↓");
        rc.getSelectionModel().select("Trier");*/
        commandeservice cs=new commandeservice();
        try {
            List<commande> co=cs.recuperer();
            ObservableList<commande> ob= FXCollections.observableList(co);
            tab.setItems(ob);
            tabi.setCellValueFactory(new PropertyValueFactory<>("idc"));
            tabt.setCellValueFactory(new PropertyValueFactory<>("tel"));
            tabn.setCellValueFactory(new PropertyValueFactory<>("mail"));
            tabp.setCellValueFactory(new PropertyValueFactory<>("nom"));
            tabe.setCellValueFactory(new PropertyValueFactory<>("pre"));
            taba.setCellValueFactory(new PropertyValueFactory<>("addr"));
            tabr.setCellValueFactory(new PropertyValueFactory<>("pani"));

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

}


    @FXML
    void recherchecommande(KeyEvent event) {


        FilteredList<commande> filter = new FilteredList<>(list, ev -> true);


        // Add a listener on the text property of the search field to update the predicate of the FilteredList
       rc.textProperty().addListener((observable, oldValue, newValue) -> {
           filter.setPredicate(commande -> {
               if (newValue == null || newValue.isEmpty()) {
                   return true; // Show all items when the filter text is empty.
               }

               String lowerCaseFilter = newValue.toLowerCase();

               if (commande.getNom().toLowerCase().contains(lowerCaseFilter)) {
                   return true; // Filter matches nom.
               }

               return false; // Does not match.
           });
       });

        // Create a SortedList from the FilteredList to sort the results
        SortedList<commande> sort = new SortedList<>(filter);
        // Bind the comparator of the SortedList with the comparator of the TableView
        sort.comparatorProperty().bind(tab.comparatorProperty());
        // Set the items of the TableView to the SortedList
        tab.setItems(sort);

    }
    /*@FXML
    void trier(ActionEvent event) throws SQLException {
        String selected = sc.getSelectionModel().getSelectedItem();
         List<commande> temp;
        temp = null;
        if (selected.equals("Trier par Nom asc ")) {
            temp = css.tri_par_nom();

        } else if (selected.equals("Trier par Nom des")) {
            temp = css.tri_par_nom2();

        }
        // Mettez à jour la liste observable utilisée par votre TableView (par exemple, 'list')
        ObservableList<commande> updatedList = FXCollections.observableArrayList(temp);

        // Mettre à jour la TableView
        tab.setItems(updatedList);

    }*/
    @FXML
    void triasc(ActionEvent event) {
        List<commande> temp;
        temp = null;
        try {
            temp = css.tri_par_nom();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        ObservableList<commande> updatedList = FXCollections.observableArrayList(temp);

        // Mettre à jour la TableView
        tab.setItems(updatedList);
    }

    @FXML
    void tridesc(ActionEvent event) {
        List<commande> temp;
        temp = null;
        try {
            temp = css.tri_par_nom2();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        ObservableList<commande> updatedList = FXCollections.observableArrayList(temp);

        // Mettre à jour la TableView
        tab.setItems(updatedList);
    }
    public void pdf(ActionEvent actionEvent) throws IOException {
        ObservableList<commande> data = tab.getItems();

        try {
            // Créez un nouveau document PDF
            PDDocument document = new PDDocument();

            // Créez une page dans le document
            PDPage page = new PDPage();
            document.addPage(page);

            // Obtenez le contenu de la page
            PDPageContentStream contentStream = new PDPageContentStream(document, page);

            // Écrivez du texte dans le document
            contentStream.setFont(PDType1Font.HELVETICA_BOLD, 12);
            contentStream.beginText();
            contentStream.newLineAtOffset(100, 700);


            for (commande categorie : data) {
// Ajouter l'image
                /*String imagePath = uploads + categorie.getCategorie();
                PDImageXObject pdImage = PDImageXObject.createFromFile(imagePath, document);*/

                String ligne = "ID : " + categorie.getIdc() + "     Nom : " + categorie.getNom()
                        +"     tel : " + categorie.getTel()+"     mail : " + categorie.getMail()
                        +"    addresse : " + categorie.getAddr()+"     Votre Panier : " + categorie.getPani();
                contentStream.showText(ligne);

                contentStream.newLine();;
                contentStream.newLineAtOffset(0, -15);


            }

            contentStream.endText();

            // Fermez le contenu de la page
            contentStream.close();

            String outputPath ="C:/Users/user/Desktop/az/a.pdf";
            File file = new File(outputPath);
            document.save(file);

            // Fermez le document
            document.close();

            System.out.println("Le PDF a été généré avec succès.");
            Desktop.getDesktop().open(file);
        } catch (IOException e) {
            e.printStackTrace();
        }


    }}

