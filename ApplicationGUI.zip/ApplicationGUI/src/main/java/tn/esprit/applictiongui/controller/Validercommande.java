package tn.esprit.applictiongui.controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import tn.esprit.applictiongui.model.commande;
import tn.esprit.applictiongui.model.panier;
import tn.esprit.applictiongui.service.commandeservice;
import tn.esprit.applictiongui.service.panierservice;
import util.mydatabase;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

public class Validercommande {


    @FXML
    private TextField addr;

    @FXML
    private TextField mail;

    @FXML
    private TextField nom;

    @FXML
    private TextField pre;

    @FXML
    private TableView<panier> taborder;

    @FXML
    private TableColumn<?, ?> tabp;

    @FXML
    private TableColumn<?, ?> tabpro;

    @FXML
    private TableColumn<?, ?> tabq;

    @FXML
    private TextField tel;

    @FXML
    private Label tot;
    private int tota;
    private Connection connection;
  public Validercommande(){connection= mydatabase.getInstance().getConnection();}
    @FXML
    void ajouter(ActionEvent event) {
        commandeservice cs = new commandeservice();
        commande co = new commande();
        co.setNom(nom.getText());
        co.setPre(pre.getText());
        co.setMail(mail.getText());
        co.setAddr(addr.getText());
        co.setTel(Integer.parseInt(tel.getText()));

        try {
            cs.ajouter(co);
            Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
            alert.setTitle("success");
            alert.setContentText("personne ajoutee");
            alert.showAndWait();
        } catch (SQLException ex) {

            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Erreur");

            alert.showAndWait();
        }
    }

public void menutotal() throws SQLException {
        String req="SELECT SUM(pt) FROM panier";
    PreparedStatement pre=connection.prepareStatement(req);
    ResultSet res=pre.executeQuery();
    if(res.next()){
        tota=res.getInt("SUM(pt)");

    }
    tot.setText(tota+""+"DT");

}
    @FXML
    void initialize() {
        panierservice pa=new panierservice();
        try {
            List<panier> co=pa.recuperer();
            ObservableList<panier> ob= FXCollections.observableList(co);
            taborder.setItems(ob);

            tabq.setCellValueFactory(new PropertyValueFactory<>("quantite"));
            tabpro.setCellValueFactory(new PropertyValueFactory<>("nomp"));
            tabp.setCellValueFactory(new PropertyValueFactory<>("pt"));

            menutotal();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }
}